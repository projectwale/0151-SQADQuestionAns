from flask import Flask, render_template, request, session, redirect, url_for
import pymysql
import nltk
import json
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

from tensorflow.keras.layers import LSTM, Dense, Dropout, Input,RepeatVector
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Embedding
from tensorflow.keras.layers import add

app = Flask(__name__)
app.secret_key = 'any random string'

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="questionanswering")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

globalContext = ''
lookup = 'abcdefghijklmnopqrstuvwxyz1234567890?.,'

input_paragraph_max_seq_length =100  
input_question_max_seq_length = 1
target_max_seq_length = 0

with open('input_paragraph_word2idx.json', "r") as file:
    input_paragraph_word2idx = json.load(file)
with open('input_question_word2idx.json', "r") as file:
    input_question_word2idx = json.load(file)
with open('target_word2idx.json', "r") as file:
    target_word2idx = json.load(file)

input_paragraph_idx2word = dict([(idx, word) for word, idx in input_paragraph_word2idx.items()])
input_question_idx2word = dict([(idx, word) for word, idx in input_question_word2idx.items()])
target_idx2word = dict([(idx, word) for word, idx in target_word2idx.items()])

num_input_paragraph_tokens = len(input_paragraph_idx2word)
num_input_question_tokens = len(input_question_idx2word)
num_target_tokens = len(target_idx2word)

def in_white_list(_word):
    valid_word = False
    for char in _word:
        if char in lookup:
            valid_word = True
            break

    if valid_word is False:
        return False
    return True

hidden_units = 256
embed_hidden_units = 100

context_inputs = Input(shape=(None,), name='context_inputs')
encoded_context = Embedding(input_dim=num_input_paragraph_tokens, output_dim=embed_hidden_units,
                                input_length=input_paragraph_max_seq_length,
                                name='context_embedding')(context_inputs)
encoded_context = Dropout(0.3)(encoded_context)

question_inputs = Input(shape=(None,), name='question_inputs')
encoded_question = Embedding(input_dim=num_input_question_tokens+1, output_dim=embed_hidden_units,
                                 input_length=input_question_max_seq_length,
                                 name='question_embedding')(question_inputs)
encoded_question = Dropout(0.3)(encoded_question)
encoded_question = LSTM(units=embed_hidden_units, name='question_lstm')(encoded_question)
encoded_question = RepeatVector(input_paragraph_max_seq_length)(encoded_question)

merged = add([encoded_context, encoded_question])

encoder_lstm = LSTM(units=hidden_units, return_state=True, name='encoder_lstm')
encoder_outputs, encoder_state_h, encoder_state_c = encoder_lstm(merged)
encoder_states = [encoder_state_h, encoder_state_c]

decoder_inputs = Input(shape=(None, num_target_tokens), name='decoder_inputs')
decoder_lstm = LSTM(units=hidden_units, return_state=True, return_sequences=True, name='decoder_lstm')
decoder_outputs, decoder_state_h, decoder_state_c = decoder_lstm(decoder_inputs,
                                                                     initial_state=encoder_states)
decoder_dense = Dense(units=num_target_tokens, activation='softmax', name='decoder_dense')
decoder_outputs = decoder_dense(decoder_outputs)

model = Model([context_inputs, question_inputs, decoder_inputs], decoder_outputs)
model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])

encoder_model = Model([context_inputs, question_inputs], encoder_states)

decoder_state_inputs = [Input(shape=(hidden_units,)), Input(shape=(hidden_units,))]
decoder_outputs, state_h, state_c = decoder_lstm(decoder_inputs, initial_state=decoder_state_inputs)
decoder_states = [state_h, state_c]
decoder_outputs = decoder_dense(decoder_outputs)
decoder_model = Model([decoder_inputs] + decoder_state_inputs, [decoder_outputs] + decoder_states)

def reply(paragraph, question):
    input_paragraph_seq = []
    input_question_seq = []
    input_paragraph_wid_list = []
    input_question_wid_list = []
    input_paragraph_text = paragraph.lower()
    input_question_text = question.lower()
    for word in nltk.word_tokenize(input_paragraph_text):
        if not in_white_list(word):
            continue
        idx = 1  # default [UNK]
        if word in input_paragraph_word2idx:
            idx = input_paragraph_word2idx[word]
        input_paragraph_wid_list.append(idx)
    for word in nltk.word_tokenize(input_question_text):
        if not in_white_list(word):
            continue
            idx = 1  # default [UNK]
        if word in input_question_word2idx:
            idx = input_question_word2idx[word]
        input_question_wid_list.append(idx)
    input_paragraph_seq.append(input_paragraph_wid_list)
    input_question_seq.append(input_question_wid_list)

    input_paragraph_seq = pad_sequences(input_paragraph_seq, input_paragraph_max_seq_length)
    input_question_seq = pad_sequences(input_question_seq, input_question_max_seq_length)
    states_value = encoder_model.predict([input_paragraph_seq, input_question_seq])

    target_seq = np.zeros((1, 1, num_target_tokens))
    target_seq[0, 0, target_word2idx['START']] = 1
    target_text = ''
    target_text_len = 0
    terminated = False
    while not terminated:
        output_tokens, h, c = decoder_model.predict([target_seq] + states_value)

        sample_token_idx = np.argmax(output_tokens[0, -1, :])
        sample_word = target_idx2word[sample_token_idx]
        target_text_len += 1

        if sample_word != 'START' and sample_word != 'END':
            target_text += ' ' + sample_word

        if sample_word == 'END' or target_text_len >= target_max_seq_length:
            terminated = True

        target_seq = np.zeros((1, 1, num_target_tokens))
        target_seq[0, 0, sample_token_idx] = 1

        states_value = [h, c]
    return target_text.strip()

# ---------------------------------------------------------------------------------------------------

@app.route('/')
def main():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']
        
        sql1 = "INSERT INTO register(username, email, mobile, password) VALUES (%s, %s, %s, %s);"
        val1 = (username, email, mobile, password)
        cursor.execute(sql1,val1)
        con.commit()
        
        return redirect(url_for("main"))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        details = request.form
        
        username = details['username']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username, password))
        count = cursor.rowcount
        if count > 0:        
            session['username'] = username
            return redirect(url_for("index"))
        else:
            return redirect(url_for("main"))
        
    return render_template('login.html')  

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/logout')
def logout():
    return render_template('login.html') 

@app.route('/askquestion', methods=['GET', 'POST'])
def askquestion():
    if request.method == "POST":
        details = request.form
        
        global globalContext
        
        userMessage = details['userMessage']
        category = details['category']
        
        if category == 'Context': 
            globalContext = userMessage
            return ""
        else:
            # print(globalContext)
            # print(userMessage)
            predicted_answer = reply(globalContext, userMessage)            
            return str(predicted_answer)
    return render_template('askQuestion.html')

@app.route('/reservation')
def reservation():
    return render_template('reservation.html')


@app.route('/feature')
def feature():
    return render_template('feature.html')


@app.route('/faq')
def faq():
    return render_template('faq.html')


@app.route('/roadmap')
def roadmap():
    return render_template('roadmap.html')

@app.route('/error')
def error():
    return render_template('error.html')

@app.route('/about')
def about():
    return render_template('about.html')


if __name__ == '__main__':
    # app.run(debug=True)
    app.run('0.0.0.0')