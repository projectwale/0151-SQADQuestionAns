from flask import Flask, render_template, request, session, redirect, url_for
import pymysql
import torch
from transformers import AutoTokenizer
from tensorflow.keras.models import load_model

import nltk
# nltk.download("punkt")
import json
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

app = Flask(__name__)
app.secret_key = 'any random string'

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="questionanswering")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

# Define the bert tokenizer
tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

# Load the fine-tuned modeol
model = torch.load("finetunedmodel",map_location=torch.device('cpu'))
model.eval()

def predict(context,query):

  inputs = tokenizer.encode_plus(query, context, return_tensors='pt')

  outputs = model(**inputs)
  answer_start = torch.argmax(outputs[0])  # get the most likely beginning of answer with the argmax of the score
  answer_end = torch.argmax(outputs[1]) + 1 

  answer = tokenizer.convert_tokens_to_string(tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

  return answer

def normalize_text(s):
  """Removing articles and punctuation, and standardizing whitespace are all typical text processing steps."""
  import string, re

  def remove_articles(text):
    regex = re.compile(r"\b(a|an|the)\b", re.UNICODE)
    return re.sub(regex, " ", text)

  def white_space_fix(text):
    return " ".join(text.split())

  def remove_punc(text):
    exclude = set(string.punctuation)
    return "".join(ch for ch in text if ch not in exclude)

  def lower(text):
    return text.lower()

  return white_space_fix(remove_articles(remove_punc(lower(s))))

def compute_exact_match(prediction, truth):
    return int(normalize_text(prediction) == normalize_text(truth))

def compute_f1(prediction, truth):
  pred_tokens = normalize_text(prediction).split()
  truth_tokens = normalize_text(truth).split()
  
  # if either the prediction or the truth is no-answer then f1 = 1 if they agree, 0 otherwise
  if len(pred_tokens) == 0 or len(truth_tokens) == 0:
    return int(pred_tokens == truth_tokens)
  
  common_tokens = set(pred_tokens) & set(truth_tokens)
  
  # if there are no common tokens then f1 = 0
  if len(common_tokens) == 0:
    return 0
  
  prec = len(common_tokens) / len(pred_tokens)
  rec = len(common_tokens) / len(truth_tokens)
  
  return 2 * (prec * rec) / (prec + rec)

# ---------------------------------------------------------------------------------------------------

encoded_model=load_model("encoder_model.h5")
decoder_model=load_model("decoder_model.h5")

globalContext = ''
lookup = 'abcdefghijklmnopqrstuvwxyz1234567890?.,'
# check for valid characters
def in_white_list(_word):
    valid_word = False
    for char in _word:
        if char in lookup:
            valid_word = True
            break

    if valid_word is False:
        return False
    return True

input_paragraph_max_seq_length =298  
input_question_max_seq_length = 32
target_max_seq_length = 36

with open('input_paragraph_word2idx.json', "r") as file:
    input_paragraph_word2idx = json.load(file)
with open('input_question_word2idx.json', "r") as file:
    input_question_word2idx = json.load(file)
with open('target_word2idx.json', "r") as file:
    target_word2idx = json.load(file)

input_paragraph_idx2word = dict([(idx, word) for word, idx in input_paragraph_word2idx.items()])
input_question_idx2word = dict([(idx, word) for word, idx in input_question_word2idx.items()])
target_idx2word = dict([(idx, word) for word, idx in target_word2idx.items()])

num_input_paragraph_tokens = len(input_paragraph_idx2word)
num_input_question_tokens = len(input_question_idx2word)
num_target_tokens = len(target_idx2word)

def reply(paragraph, question):
    input_paragraph_seq = []
    input_question_seq = []
    input_paragraph_wid_list = []
    input_question_wid_list = []
    input_paragraph_text = paragraph.lower()
    input_question_text = question.lower()
    for word in nltk.word_tokenize(input_paragraph_text):
        if not in_white_list(word):
            continue
        idx = 1  # default [UNK]
        if word in input_paragraph_word2idx:
            idx = input_paragraph_word2idx[word]
        input_paragraph_wid_list.append(idx)
    for word in nltk.word_tokenize(input_question_text):
        if not in_white_list(word):
            continue
            idx = 1  # default [UNK]
        if word in input_question_word2idx:
            idx = input_question_word2idx[word]
        input_question_wid_list.append(idx)
    input_paragraph_seq.append(input_paragraph_wid_list)
    input_question_seq.append(input_question_wid_list)

    input_paragraph_seq = pad_sequences(input_paragraph_seq, input_paragraph_max_seq_length)
    input_question_seq = pad_sequences(input_question_seq, input_question_max_seq_length)
#     print(input_paragraph_seq)
#     print(input_question_seq)
    # print()
    # print(input_paragraph_seq.shape)
    # print(input_question_seq.shape)   
    
    states_value = encoded_model.predict([input_paragraph_seq, input_question_seq])

    target_seq = np.zeros((1, 1, num_target_tokens))
    target_seq[0, 0, target_word2idx['START']] = 1
    target_text = ''
    target_text_len = 0
    terminated = False
    while not terminated:
        output_tokens, h, c = decoder_model.predict([target_seq] + states_value)

        sample_token_idx = np.argmax(output_tokens[0, -1, :])
        sample_word = target_idx2word[sample_token_idx]
        target_text_len += 1

        if sample_word != 'START' and sample_word != 'END':
            target_text += ' ' + sample_word

        if sample_word == 'END' or target_text_len >= target_max_seq_length:
            terminated = True

        target_seq = np.zeros((1, 1, num_target_tokens))
        target_seq[0, 0, sample_token_idx] = 1

        states_value = [h, c]
    return target_text.strip()
# ---------------------------------------------------------------------------------------------------

@app.route('/')
def main():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']
        
        sql1 = "INSERT INTO register(username, email, mobile, password) VALUES (%s, %s, %s, %s);"
        val1 = (username, email, mobile, password)
        cursor.execute(sql1,val1)
        con.commit()
        
        return redirect(url_for("main"))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        details = request.form
        
        username = details['username']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username, password))
        count = cursor.rowcount
        if count > 0:        
            session['username'] = username
            return redirect(url_for("askquestion"))
        else:
            return redirect(url_for("main"))
        
    return render_template('login.html')  

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/logout')
def logout():
    return render_template('login.html') 

@app.route('/askquestion', methods=['GET', 'POST'])
def askquestion():
    if request.method == "POST":
        details = request.form
        
        global globalContext
        
        userMessage = details['userMessage']
        category = details['category']
        
        if category == 'Context': 
            globalContext = userMessage
            return ""
        else:
            # print(globalContext)
            # print(userMessage)
            predicted_answer = reply(globalContext, userMessage)
            prediction = predict(globalContext,userMessage)
            
            if prediction == '':               
                return str(predicted_answer)+'&&'+'None'
            elif predicted_answer == '':
                return 'None'+'&&'+str(prediction)
            else:                
                return str(predicted_answer)+'&&'+str(prediction)
                
    return render_template('askQuestion.html')

@app.route('/reservation')
def reservation():
    return render_template('reservation.html')


@app.route('/feature')
def feature():
    return render_template('feature.html')


@app.route('/faq')
def faq():
    return render_template('faq.html')


@app.route('/roadmap')
def roadmap():
    return render_template('roadmap.html')

@app.route('/error')
def error():
    return render_template('error.html')

@app.route('/about')
def about():
    return render_template('about.html')


if __name__ == '__main__':
    app.run(debug=True)
    # app.run('0.0.0.0')